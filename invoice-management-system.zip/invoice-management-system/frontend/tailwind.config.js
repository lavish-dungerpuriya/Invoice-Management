// tailwind.config.js
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}", // include this path for React files
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
